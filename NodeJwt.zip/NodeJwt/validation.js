
const Joi = require('@hapi/joi');

// Register validation 

 const registrationValidation = (data )=>{
    const schema = Joi.object({
    name : Joi.string().min(6).required(),
    email : Joi.string().min(6).required().email(),
    password : Joi.string().min(6).required()
    });

    const validation = schema.validate(data);
    //console.log("validation is " , validation);
    //const error =  validation.error.details[0].message;
    //console.log("error is" , error);
     //return error;
     
     //const error =  validation.error.details[0].message;
}

// Login Validation

const loginValidation = (data )=>{
    const schema = Joi.object({
    
    email : Joi.string().min(6).required().email(),
    password : Joi.string().min(6).required()
    });

    const validation = schema.validate(data);
    const error =  validation.error.details[0].message;

    //console.log("error is" , error);
    return error;
}

module.exports.registrationValidation = registrationValidation;
module.exports.loginValidation = loginValidation;