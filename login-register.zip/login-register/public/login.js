jQuery(document).ready(function(){
    jQuery("#regBtn").click(function(){
        jQuery.ajax({
            type : 'GET',
            url : '/register',
            success : function(data){
                   jQuery("#regDiv").html(data);           
            }

        })
    })




jQuery("#loginBtn").click(function(){
    jQuery.ajax({
        type : 'GET',
        url  : '/login',
        success : function(data){
            jQuery("#loginDiv").html(data)
        }
    })
})



// Login form request 



jQuery("#loginForm").click(function(){
    var uname   =  jQuery("#uname").val();
    var upass   =  jQuery("#upass").val();
    var loginData  =  {'name' : uname , 'pass'  : upass}
    jQuery.ajax({
        type  : 'POST',
        url  : '/demo',
        data : loginData,
        success  : function(data){
            jQuery("mainDiv").html(data);
        }
    })
})




// Register Form 

jQuery("#regForm").click(function(){
    var uname  = $("#uname").val();
    var upass = $("#upass").val();
    var regData ={'name': uname,'pass':upass};
      jQuery.ajax({
        type : 'POST',
        url : '/registerToDb',
        data : regData,
        success: function(data){
        $("#mainDiv").html(data);
        }
      });
  });



   //Save profile Data=====================

jQuery('#saveBtn').click(function(){
    var email = jQuery("#email").val();
    var phone = jQuery("#phone").val();
    var education = jQuery("#education").val();
    var aoi = jQuery("#aoi").val();
    var name = jQuery("#name").val();
    var pass = jQuery("#pass").val();
    var profileData = {'email':email,'phone':phone,'education' : education,'aoi':aoi,'name' : name,'pass' : pass};
    jQuery.ajax({
      type : 'POST',
      url : '/completeprofile',
      data : profileData,
      success : function(data){
        jQuery("#mainDiv").html(data);
      }
    });
  });
});  

