const express = require("express");
const app = express();
const dotenv = require('dotenv');

dotenv.config();
const AWS  = require("aws-sdk");
//console.log("cxc" , process.env.accessKeyId);

AWS.config.update({
    accessKeyId: process.env.accessKeyId,
    secretAccessKey: process.env.secretAccessKey,
    region: "us-east-1",
  });

//Import Routes 

const authRoute = require('./routes/auth');
const postRoute = require('./routes/post');

//MiddleWare 

app.use(express.json());




//Routes Middlewares 
app.use('/api/user',authRoute);
app.use('/api/post',postRoute);

app.listen(3000,()=>{
     console.log("server up and running");
})


//eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiYW5rdXIiLCJpYXQiOjE1ODQwODMyNDd9.NrJvW4bF4xah9hO6z9NB2iXYinq9QLq-GSxWVq284Ik