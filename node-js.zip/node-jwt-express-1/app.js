const express = require('express');
const jwt = require('jsonwebtoken');

const app = express();

app.get('/' , (req,res)=>{
    res.json("welcome to the api");
});


app.post('/api/posts',verifyToken ,(req,res)=>{
    jwt.verify(req.token,'secretkey',(err,authData)=>{
        if(err){
            res.sendStatus(403)
        }
        else {
            res.json({
                message : 'post created',
                authData  
            });
        }
    });
    
});


app.post('/api/login',(req,res)=>{
    const user = {
       id:1,
       username : 'Ketan',
       email : 'tayalket@gmail.com' 
    }
    jwt.sign({user:user},'secretkey' , {expiresIn:'60s'}, (err,token)=>{
            res.json({
                token : token
            });
    });
});

//Verify Token

function verifyToken(req,res,next){
        //get auth header value
        const bearerHeader = req.headers['authorization']; 
            if(bearerHeader){
                const bearer = bearerHeader.split(' ');
                //Get Token from array
                const bearerToken = bearer[1];
                req.token = bearerToken;
                next();
            } else {
                res.sendStatus(403);
            }
    }

app.listen(5000,()=>{
    console.log("Server started on port 5000");
})

