curl -XPUT https://vpc-es-test-domain-5yg4ut73rqwiebbqtsyay74nwq.us-east-1.es.amazonaws.com/movies/_doc/1 -d '{"director": "Burton, Tim", "genre": ["Comedy","Sci-Fi"], "year": 1996, "actor": ["Jack Nicholson","Pierce Brosnan","Sarah Jessica Parker"], "title": "Mars Attacks!"}' -H 'Content-Type: application/json'
https://vpc-es-test-domain-5yg4ut73rqwiebbqtsyay74nwq.us-east-1.es.amazonaws.com


POST https://vpc-es-test-domain-5yg4ut73rqwiebbqtsyay74nwq.us-east-1.es.amazonaws.com/movies/_doc
{"title": "Spirited Away"}

Insert Query

curl -XPUT https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc/1 -d '{"director": "Burton, Tim", "genre": ["Comedy","Sci-Fi"], "year": 1996, "actor": ["Jack Nicholson","Pierce Brosnan","Sarah Jessica Parker"], "title": "Mars Attacks!"}' -H 'Content-Type: application/json'



Search Query
curl -XGET 'https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc?search_type=_doc&scroll=10m&size=50' -d '
{
    "query" : {
        "match_all" : {}
    }
}'



https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc
{
  "size": 10
  "from": 0
  "query":
   {
    "match_all": {}
   }
}   



curl -XGET 'https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc' -d '


GET https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc




curl -XGET 'https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com//movies/_doc?search_type=_doc&scroll=10m&size=50' -d '
{
    "query" : {
        "match_all" : {}
    }
}'


https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc?size=50&pretty=true&q=


https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc?pretty=true&q=*:*
https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com

https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com


http://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc?size=1&q=*:*


curl -XGET "https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/movies/_doc" -H 'Content-Type: application/json' -d'
{
"query": {
"match_all": {}
}
}
'