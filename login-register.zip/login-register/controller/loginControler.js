const  bodyParser =  require('body-parser');
const urlEncodedParser  =  bodyParser.urlencoded({extended:false});
const mongoose = require('mongoose');

// var uri = 'mongodb+srv://notes:notes@cluster0-skv5f.mongodb.net/test?retryWrites=true&w=majority';
//    var db = mongoose.connect(uri).catch((error) => { console.log(error); });

   const MongoClient = require('mongodb').MongoClient;
//    const url = "mongodb+srv://login:login@cluster0-gkl9v.mongodb.net/test?retryWrites=true&w=majority";
//    const url = "mongodb://login:login@cluster0-shard-00-00-gkl9v.mongodb.net:27017,cluster0-shard-00-01-gkl9v.mongodb.net:27017,cluster0-shard-00-02-gkl9v.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority";
   var url = 'mongodb://localhost:27017/mydb'
   


   module.exports = (function(app){
      
       app.get('/' , function(req,res){
            res.render('home');
       });
   
       app.get('/register' , function(req,res){
        res.render('register');  
       })

   app.get('/login' , function(req,res){
       res.render('login');
   })


    // Login to db

      
    app.post('/demo'  , urlEncodedParser  ,function(req,res){
        MongoClient.connect(url, function(err,db){
            db.collection('userprofile').findOne({name : req.body.name},  function(err,user){
                if(user === null){
                    console.log("Null");     
                    res.end("Login Invalid");
                }
                else if (user.name === req.body.name  && user.pass === req.body.pass ){
                    // res.render('completeprofile' ,  {profileData: user})
                    res.end("Login Successfull");
                }
                 else {
                     console.log("Credentials Wrong");
                      res.end("Login Invalid");
                 }
            });
        });
    });


    // Register to db

     app.post('/registerToDb', urlEncodedParser , function(req,res){
         var obj = JSON.stringify(req.body);
         var jsonObj = JSON.parse(obj);
         res.render('profile' , {loginData :  req.body})
     })



     app.post('/completeprofile' , urlEncodedParser , function(req,res){
        var obj = JSON.stringify(req.body);
          var jsonObj = JSON.parse(obj);
          MongoClient.connect(url, function(err, db) {
          db.collection("userprofile").insertOne(jsonObj, function(err, res) {
          if (err) throw err;
           db.close();
            });
          res.render('completeprofile'  ,{profileData:req.body});
            res.end();
        });
    });
});









{product : "toothbrush" , total : 4.75 , customer : "Mike"},{product : "pizza" , total : 4.75 , customer : "TOm"},{product : "pizza" , total : 4.75 , customer : "TOm"},{product : "toothbrush" , total : 4.75 , customer : "Dave"},{product : "toothbrush" , total : 4.75 , customer : "Dave"},{product : "guitar" , total : 4.75 , customer : "Karen"}

{ _id: 1, cust_id: "abc1", ord_date: ISODate("2012-11-02T17:04:11.102Z"), status: "A", amount: 50 },{ _id: 2, cust_id: "xyz1", ord_date: ISODate("2013-10-01T17:04:11.102Z"), status: "A", amount: 100 },{ _id: 3, cust_id: "xyz1", ord_date: ISODate("2013-10-12T17:04:11.102Z"), status: "D", amount: 25 },{ _id: 4, cust_id: "xyz1", ord_date: ISODate("2013-10-11T17:04:11.102Z"), status: "D", amount: 125 },{ _id: 5, cust_id: "abc1", ord_date: ISODate("2013-11-12T17:04:11.102Z"), status: "A", amount: 25 }


