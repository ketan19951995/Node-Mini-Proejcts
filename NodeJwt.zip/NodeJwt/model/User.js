
var AWS = require("aws-sdk");
AWS.config.update({
  accessKeyId: 'AKIAV4GWRRKZRRZE2S5J',
  secretAccessKey: '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',
  region: "us-east-1",
});


var dynamodb = new AWS.DynamoDB();

var params = {
    TableName : "UsersJWT",
    KeySchema : [
        { AttributeName: "email", KeyType: "HASH" }, 
        { AttributeName: "name", KeyType: "RANGE"}, 
        
      ],

    AttributeDefinitions: [
        {AttributeName: "name",AttributeType: "S"},
        {AttributeName: "email",AttributeType: "S"},
        {AttributeName: "password",AttributeType: "S"},
        {AttributeName: "date",AttributeType: "N"},
    ],
    ProvisionedThroughput: {       
        ReadCapacityUnits: 10, 
        WriteCapacityUnits: 10
    },

    GlobalSecondaryIndexes: [{
        IndexName: "UserIndex",
        KeySchema: [
            {
                AttributeName: "password",
                KeyType: "HASH"
                },
            {
                AttributeName: "date",
                KeyType: "RANGE"
            }
        ],
        Projection: {
            ProjectionType: "ALL"
            },
        ProvisionedThroughput: {
            ReadCapacityUnits: 1,
            WriteCapacityUnits: 1
            }
        }]
    };




dynamodb.createTable(params,function(err,data){
    if (err) {
        console.error("Unable to create table. Error JSON:", JSON.stringify(err, null, 2));
    } else {
        console.log("Created table. Table description JSON:", JSON.stringify(data, null, 2));
    }
});