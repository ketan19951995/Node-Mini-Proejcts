'use strict';

const {BigQuery} = require('@google-cloud/bigquery');
const bigquery = new BigQuery();

const projectId = "es-test-domain-gcp-analytics";
const datasetId = "TestDataSet";
const tableId = "properties_rent_201501";



function main(datasetId ='TestDataSet', tableId ='properties_rent_201501') {
  
    async function browseRows() {
      
    // Displays rows from "my_table" in "my_dataset".
    
    try {
    // List rows in the table
        const [rows] = await bigquery
            .dataset(datasetId)
            .table(tableId)
            .getRows();

        console.log('Rows:');
        rows.forEach(row => console.log(row));
     }
    catch (err){
    console.log(err); 
    }
 }
  
  // [END bigquery_browse_table]
  browseRows();
}

//main(...process.argv.slice(2));



async function queryBatch(){
const query = `SELECT id
                    FROM \`es-test-domain-gcp-analytics.TestDataSet.properties_rent_201501\` 
                    LIMIT 10`; 


       const query1 = `SELECT MIN(price) AS SmallestPrice
                FROM \`es-test-domain-gcp-analytics.TestDataSet.properties_rent_201501\` `;

        // const jobConfig = {
        //     query: query,
//     // Location must match that of the dataset(s) referenced in the query.
//     // location: 'US',
//     // params: {corpus: 'romeoandjuliet', min_word_count: 250},
//   };
    
        const [job] = await bigquery.createQueryJob(query1);
        console.log("job is" , job);
        const jobId = job.metadata.id;
        const state = job.metadata.status.state;
        

        console.log(`Jobbb ${jobId} is currently in state ${state}`); 
    
    
        // Wait for the query to finish
        const [rows] = await job.getQueryResults();
        console.log('Rows:');
        rows.forEach(row => console.log(row));
}
    queryBatch();