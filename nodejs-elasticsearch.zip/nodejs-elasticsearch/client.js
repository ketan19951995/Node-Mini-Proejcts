const es = require('elasticsearch');
const esClient = new es.Client({
    //host : 'localhost:9200',
    host: 'https://search-es-test-new-domain-bupprzzf4lbqpherryrundjbyy.us-east-1.es.amazonaws.com/',
    log : 'trace'
})


module.exports = esClient;

