const esClient = require('./client');
let allRecords = [];

// const searchDoc = async function(indexName,mappingType,payload){
//     return await esClient.search({
//         index: indexName,
//         type : mappingType,
//         body : payload
//     });
// }


// const searchDoc1  = async function(indexName,mappingType,payload){
//     return await esClient.search({
//         index :indexName,
//         type : mappingType,
//         body : payload  
//     });
// } 


const getAll = async function(indexName,mappingType,payload){
    return await esClient.search({
      index : indexName,
      type : mappingType,
      scroll : '10s',
      body : payload  
    });
}

// module.exports = searchDoc;

// module.exports = searchDoc1;

module.exports  = getAll;



// async function test(){
//     const body = {
//         query : {
//             match_phrase_prefix : {
//                 "title" : "lea"            
//             }
//         }
//     }
// }



async function test2(){
    const body = {
        query: {
            "match_all": {}
        },
        _source: false
    }
    try {
        const resp = await getAll('movies','_doc',body);
        console.log(resp.hits.hits.length);
        console.log("response is" , resp.hits.hits);

 } catch(e){
     console.log(e);
 }
}

// async function test1(){
//     const body = {
//         query : {
//             match : {
//                 "title" : "LEARN"
//             }
//         },

//         aggs : {
//             tags : {
//                 terms : {
//                     fields : 'tags'
//                 }
//             }
//         }
//     }

//     try {
//         const resp = await searchDoc1('blog','ciphertext',body);
//         console.log(JSON.Stringify(resp));
//     }
//     catch(e){
//         console.log(e);
//     }
// }

test2();