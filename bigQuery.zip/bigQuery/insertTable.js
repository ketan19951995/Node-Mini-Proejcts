const  datasetId = "TestDataSet";
const   tableId = "moviesTableUpdated";


schema = [
    {name: 'show_id', type: 'INTEGER'},
    {name: 'type', type: 'STRING'},
    {name: 'title', type: 'STRING'},
    {name: 'director', type: 'STRING'},
    {name: 'cast', type: 'STRING'},
    {name: 'country', type: 'STRING'},
    {name: 'date_added', type: 'STRING'},
    {name: 'release_year', type: 'STRING'},
    {name: 'rating', type: 'STRING'},
    {name: 'duration', type: 'STRING'},
    {name: 'listed_in', type: 'STRING'},
    {name: 'description', type: 'STRING'},
]



// [START bigquery_create_table]
// Import the Google Cloud client library and create a client
const {BigQuery} = require('@google-cloud/bigquery');
const bigquery = new BigQuery();


async function createTable(){
    const options = {
        schema: schema,
        location: 'US',
      }; 
      
      const [table] = await bigquery.dataset(datasetId).createTable(tableId,options);

      console.log(`Table ${table.id} created.`);
}

createTable();