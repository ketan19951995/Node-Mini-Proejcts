// Imports the Google Cloud client library.
const {Storage} = require('@google-cloud/storage');
const {BigQuery} = require('@google-cloud/bigquery');
 

async function authCloudImplicit(){
// Instantiates a client. Explicitly use service account credentials by
// specifying the private key file. All clients in google-cloud-node have this
// helper, see https://github.com/GoogleCloudPlatform/google-cloud-node/blob/master/docs/authentication.md
const projectId = 'es-test-domain-gcp-analytics'
const keyFilename = '/Users/admin/bigQuery/es-test-domain-gcp-analytics-2ab75770caed.json'


const storage = new Storage({projectId, keyFilename});

console.log("storage is",storage);



// Makes an authenticated API request.
try {
  const [buckets] = await storage.getBuckets();

  console.log('Buckets:' , buckets);
  buckets.forEach(bucket => {
    console.log(bucket.name);
  });
} catch (err) {
  console.error('ERROR:', err);
}
}

authCloudImplicit();

module.exports.authCloudImplicit;