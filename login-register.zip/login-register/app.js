var express = require('express');
const ejs = require('ejs');
const app = express();
const  loginController = require('./controller/loginControler');
app.set('view engine','ejs');
app.use(express.static('./public'));
loginController(app);
app.listen(3000 , ()=>{
    console.log("running on port 3000");
});
