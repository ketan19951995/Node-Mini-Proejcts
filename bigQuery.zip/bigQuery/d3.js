var data = [

    {
        "release_year": "1925",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1942",
        "ReleaseInYear": "2"
      },
      {
        "release_year": "1943",
        "ReleaseInYear": "3"
      },
      {
        "release_year": "1944",
        "ReleaseInYear": "3"
      },
      {
        "release_year": "1945",
        "ReleaseInYear": "3"
      },
      {
        "release_year": "1946",
        "ReleaseInYear": "3"
      },
      {
        "release_year": "1947",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1954",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1955",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1956",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1958",
        "ReleaseInYear": "2"
      },
      {
        "release_year": "1959",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1960",
        "ReleaseInYear": "4"
      },
      {
        "release_year": "1962",
        "ReleaseInYear": "3"
      },
      {
        "release_year": "1963",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1964",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1965",
        "ReleaseInYear": "2"
      },
      {
        "release_year": "1966",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1967",
        "ReleaseInYear": "3"
      },
      {
        "release_year": "1968",
        "ReleaseInYear": "4"
      },
      {
        "release_year": "1969",
        "ReleaseInYear": "2"
      },
      {
        "release_year": "1970",
        "ReleaseInYear": "1"
      },
      {
        "release_year": "1971",
        "ReleaseInYear": "3"
      },
      {
        "release_year": "1972",
        "ReleaseInYear": "4"
      },
      {
        "release_year": "1973",
        "ReleaseInYear": "9"
      },
      {
        "release_year": "1974",
        "ReleaseInYear": "8"
      },
      {
        "release_year": "1975",
        "ReleaseInYear": "5"
      },
      {
        "release_year": "1976",
        "ReleaseInYear": "7"
      },
      {
        "release_year": "1977",
        "ReleaseInYear": "5"
      },
      {
        "release_year": "1978",
        "ReleaseInYear": "7"
      },
      {
        "release_year": "1979",
        "ReleaseInYear": "7"
      },
      {
        "release_year": "1980",
        "ReleaseInYear": "7"
      },
      {
        "release_year": "1981",
        "ReleaseInYear": "7"
      },
      {
        "release_year": "1982",
        "ReleaseInYear": "11"
      },
      {
        "release_year": "1983",
        "ReleaseInYear": "9"
      },
      {
        "release_year": "1984",
        "ReleaseInYear": "8"
      },
      {
        "release_year": "1985",
        "ReleaseInYear": "8"
      },
      {
        "release_year": "1986",
        "ReleaseInYear": "10"
      },
      {
        "release_year": "1987",
        "ReleaseInYear": "5"
      },
      {
        "release_year": "1988",
        "ReleaseInYear": "13"
      },
      {
        "release_year": "1989",
        "ReleaseInYear": "11"
      },
      {
        "release_year": "1990",
        "ReleaseInYear": "15"
      },
      {
        "release_year": "1991",
        "ReleaseInYear": "15"
      },
      {
        "release_year": "1992",
        "ReleaseInYear": "16"
      },
      {
        "release_year": "1993",
        "ReleaseInYear": "19"
      },
      {
        "release_year": "1994",
        "ReleaseInYear": "14"
      },
      {
        "release_year": "1995",
        "ReleaseInYear": "17"
      },
      {
        "release_year": "1996",
        "ReleaseInYear": "17"
      },
      {
        "release_year": "1997",
        "ReleaseInYear": "31"
      },
      {
        "release_year": "1998",
        "ReleaseInYear": "26"
      },
      {
        "release_year": "1999",
        "ReleaseInYear": "21"
      },
      {
        "release_year": "2000",
        "ReleaseInYear": "31"
      },
      {
        "release_year": "2001",
        "ReleaseInYear": "34"
      },
      {
        "release_year": "2002",
        "ReleaseInYear": "38"
      },
      {
        "release_year": "2003",
        "ReleaseInYear": "43"
      },
      {
        "release_year": "2004",
        "ReleaseInYear": "49"
      },
      {
        "release_year": "2005",
        "ReleaseInYear": "63"
      },
      {
        "release_year": "2006",
        "ReleaseInYear": "68"
      },
      {
        "release_year": "2007",
        "ReleaseInYear": "71"
      },
      {
        "release_year": "2008",
        "ReleaseInYear": "107"
      },
      {
        "release_year": "2009",
        "ReleaseInYear": "121"
      },
      {
        "release_year": "2010",
        "ReleaseInYear": "149"
      },
      {
        "release_year": "2011",
        "ReleaseInYear": "136"
      },
      {
        "release_year": "2012",
        "ReleaseInYear": "183"
      },
      {
        "release_year": "2013",
        "ReleaseInYear": "237"
      },
      {
        "release_year": "2014",
        "ReleaseInYear": "288"
      },
      {
        "release_year": "2015",
        "ReleaseInYear": "517"
      },
      {
        "release_year": "2016",
        "ReleaseInYear": "830"
      },
      {
        "release_year": "2017",
        "ReleaseInYear": "959"
      },
      {
        "release_year": "2018",
        "ReleaseInYear": "1063"
      },
      {
        "release_year": "2019",
        "ReleaseInYear": "843"
      },
      {
        "release_year": "2020",
        "ReleaseInYear": "25"
      }
    
]

// set the dimensions of the canvas
var margin = {top: 20, right: 20, bottom: 70, left: 40},
    width = 600 - margin.left - margin.right,
    height = 300 - margin.top - margin.bottom;


// set the ranges
var x = d3.scale.ordinal().rangeRoundBands([0, width], .05);

var y = d3.scale.linear().range([height, 0]);

// define the axis
var xAxis = d3.svg.axis()
    .scale(x)
    .orient("bottom")


var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left")
    .ticks(10);


// add the SVG element
var svg = d3.select("body").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", 
          "translate(" + margin.left + "," + margin.top + ")");


// load the data
d3.json(data)
    console.log("data is ",data);

    data.forEach(function(d) {
        d.release_year = d.release_year;
        d.ReleaseInYear = +d.ReleaseInYear;
    });
	
  // scale the range of the data
  x.domain(data.map(function(d) { return d.release_year; }));
  y.domain([0, d3.max(data, function(d) { return d.ReleaseInYear; })]);

  // add axis
  svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis)
    .selectAll("text")
      .style("text-anchor", "end")
      .attr("dx", "-.8em")
      .attr("dy", "-.55em")
      .attr("transform", "rotate(-90)" );

  svg.append("g")
      .attr("class", "y axis")
      .call(yAxis)
    .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 5)
      .attr("dy", ".71em")
      .style("text-anchor", "end")
      .text("Frequency");


  // Add bar chart
  svg.selectAll("bar")
      .data(data)
    .enter().append("rect")
      .attr("class", "bar")
      .attr("x", function(d) { return x(d.release_year); })
      .attr("width", x.rangeBand())
      .attr("y", function(d) { return y(d.ReleaseInYear); })
      .attr("height", function(d) { return height - y(d.ReleaseInYear); });




