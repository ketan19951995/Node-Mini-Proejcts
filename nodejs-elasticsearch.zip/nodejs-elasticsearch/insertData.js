const esClient = require('./client');
const insertDoc = async function(indexName, _id, mappingType, data){
    return await esClient.index({
        index: indexName,
        type: mappingType,
        id: _id,
        body: data
    });
}


// const searchDoc = async function(indexName,mappingType,payload){
//     return await esClient.search({
//         index : indexName,
//         type : mappingType,
//         body : payload
//     });
// }

// module.exports = searchDoc;


// async function test1(){
//     const body = {
//         query : {
//             match : {
//                 "title" : "learn"
//             }
//         }
//     }

//     try {
//         const resp = await searchDoc('blog', 'ciphertrick', body);
//         console.log(resp);
//     } catch (e) {
//         console.log(e);
//     }
// }

async function test(){
    // const data = {
    //     title: "Learn elastic search",
    //     tags: ['NodeJS', 'Programming'],
    //     body: `Lot of content here...
    //             .... article`
    // }

    const data1 = {
        director : "Burton, Tim",
        genre: ["Comedy","Sci-Fi"], 
        year: 1996, 
        actor: ["Jack Nicholson","Pierce Brosnan","Sarah Jessica Parker"], 
        title: "Mars Attacks!"
    }

    try {
        const resp = await insertDoc('movies', 3, '_doc', data1);
        console.log(resp);
    } catch (e) {
        console.log(e);
    }
}
test();