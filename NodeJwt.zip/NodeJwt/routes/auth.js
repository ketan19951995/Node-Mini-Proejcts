const AWS  = require("aws-sdk");

AWS.config.update({
    accessKeyId: 'AKIAV4GWRRKZRRZE2S5J',
    secretAccessKey: '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',
    region: "us-east-1",
  });

var docClient = new AWS.DynamoDB.DocumentClient(); 
//console.log("doClient is " , docClient);

const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const {registrationValidation,loginValidation} = require('../validation');
//console.log("dfdsfdf",registrationValidation);
const Joi = require('@hapi/joi');

router.post('/register',(req,res)=>{

    // validate data 
     const error = registrationValidation(req.body);
     //console.log("error is  auth.js file ",error)
     //console.log ("validation is" ,validation);
    
    //console.log("name is" , req.body.name);
        if(error){
            console.log("0csdcjsdkjchksdhc");
            console.log("error is" ,error);
            //console.log("ddsfdfdf",error.error.details[0].message);
            //return res.status(400).send(error.error.details[0].message);
        }

        // checking if the user is already in the database
        
        
        var params = {
            TableName: "UsersJWT",
            Key:{
                "email" : req.body.email,
                "name" : req.body.name
            }
        };


    docClient.get(params, function(err, data) {
        console.log("csacbaskcbaskbc");
        if (err) {
            console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
        } else {
            return res.status(400).send("email already exists");
        }
    });

    //hash Password 
    var saltRounds = 10;
    bcrypt.hash(req.body.password, saltRounds).then(function(hashPassword){
    console.log("hashpassword is",hashPassword);
    var params = {
        TableName : "UsersJWT",
        Item : {
            "name" : req.body.name,
            "email" : req.body.email,
            "password" : hashPassword
        }
    };
    
    
        docClient.put(params,function(err,data){
            console.log("data is" , data);
            if(err){
                console.error("Unable to add record",req.body.name, ". Error JSON:", JSON.stringify(err, null, 2));
            } else {
                console.log("PutItem succeeded:", req.body.name);
                res.send("Record insertion successfull");
            }
    
        });
    });

});


router.post('/login',(req,res)=>{
    //const {error} = loginValidation(req.body);
    //if(error){
        //return res.status(400).send(error.details[0].message);
   // }

    // checking if the user is already in the database
        
        console.log("ddssd",req.body.email);
    var params = {
        TableName: "UsersJWT",
        Key:{
            "email" : req.body.email,
            "name" : req.body.name
        }
    };

    docClient.get(params, function(err, data) {
        
        console.log("dssdsdscsacbaskcbaskbc" , data.Item.password);
    if (!data) {
         res.status(400).send("email  is not found ");
    }
        //PASSWORD IS CORRECT
        console.log(req.body.password,"sdfsdfhsdkfh" , data.Item.password);

        bcrypt.compare(req.body.password, data.Item.password , function(err,result) {
            console.log("result is" , result);
            if(result){
               console.log("password match"); 
               const token = jwt.sign({name: req.body.name},"dfdkjshfd");
               res.header('auth-token',token).send(token);

            }
            else {
                console.log("password does not match");
            }
        });
        
});
});
module.exports = router;
